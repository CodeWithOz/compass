import type { HeatmapData } from "@/lib/mock-data";

interface ActivityHeatmapProps {
  data: HeatmapData;
  weeks?: number;
}

const ActivityHeatmap = ({ data, weeks = 16 }: ActivityHeatmapProps) => {
  const today = new Date();
  const dayOfWeek = today.getDay(); // 0=Sun

  // Build grid: columns = weeks, rows = 7 days (Mon-Sun)
  const cells: { date: string; level: number }[][] = [];

  const totalDays = weeks * 7 + dayOfWeek;
  const startDate = new Date(today);
  startDate.setDate(startDate.getDate() - totalDays + 1);

  // Adjust to start on Monday
  const startDay = startDate.getDay();
  const mondayOffset = startDay === 0 ? -6 : 1 - startDay;
  startDate.setDate(startDate.getDate() + mondayOffset);

  for (let w = 0; w < weeks; w++) {
    const week: { date: string; level: number }[] = [];
    for (let d = 0; d < 7; d++) {
      const cellDate = new Date(startDate);
      cellDate.setDate(cellDate.getDate() + w * 7 + d);
      const key = cellDate.toISOString().split("T")[0];
      const isFuture = cellDate > today;
      week.push({
        date: key,
        level: isFuture ? -1 : (data[key] || 0),
      });
    }
    cells.push(week);
  }

  const levelClass = (level: number) => {
    if (level === -1) return "bg-transparent";
    if (level === 0) return "bg-heatmap-empty";
    if (level === 1) return "bg-heatmap-low";
    if (level === 2) return "bg-heatmap-mid";
    if (level >= 3) return "bg-heatmap-max";
    return "bg-heatmap-empty";
  };

  return (
    <div className="overflow-x-auto">
      <div className="inline-flex gap-[3px]">
        {cells.map((week, wi) => (
          <div key={wi} className="flex flex-col gap-[3px]">
            {week.map((cell, di) => (
              <div
                key={di}
                className={`w-3 h-3 rounded-sm ${levelClass(cell.level)} transition-colors`}
                title={cell.level >= 0 ? `${cell.date}: ${cell.level} ${cell.level === 1 ? 'entry' : 'entries'}` : ''}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActivityHeatmap;
