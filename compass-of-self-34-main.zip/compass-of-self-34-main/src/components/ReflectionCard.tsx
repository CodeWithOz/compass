import type { WeeklyReflection } from "@/lib/mock-data";

interface ReflectionCardProps {
  reflection: WeeklyReflection;
}

const ReflectionCard = ({ reflection }: ReflectionCardProps) => {
  return (
    <div className="border rounded-md p-5 space-y-4">
      <div>
        <h3 className="text-base font-medium text-foreground">{reflection.weekLabel}</h3>
        <p className="text-xs text-muted-foreground">{reflection.dateRange}</p>
      </div>

      <div className="space-y-2">
        {reflection.resolutionSummaries.map((s) => (
          <div key={s.name} className="text-sm">
            <span className="font-medium text-foreground">{s.name}</span>
            <span className="text-muted-foreground">
              {" "}· {s.rhythm} · {s.entries} {s.entries === 1 ? "entry" : "entries"}
            </span>
          </div>
        ))}
      </div>

      <p className="prose-reflection text-sm text-foreground leading-relaxed">
        {reflection.content}
      </p>

      {reflection.note && (
        <p className="text-xs text-muted-foreground italic border-t pt-3">
          {reflection.note}
        </p>
      )}
    </div>
  );
};

export default ReflectionCard;
