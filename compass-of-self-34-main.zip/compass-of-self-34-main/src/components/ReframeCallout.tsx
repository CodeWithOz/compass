import type { Signal } from "@/lib/mock-data";

interface ReframeCalloutProps {
  signal: Signal;
}

const ReframeCallout = ({ signal }: ReframeCalloutProps) => {
  return (
    <div className="border border-signal-border bg-signal-bg rounded-md p-4">
      <p className="text-sm font-medium text-foreground">
        Pattern detected in "{signal.resolutionName}"
      </p>
      <p className="text-sm text-muted-foreground mt-1">
        → {signal.text}
      </p>
      {signal.detail && (
        <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
          {signal.detail}
        </p>
      )}
    </div>
  );
};

export default ReframeCallout;
