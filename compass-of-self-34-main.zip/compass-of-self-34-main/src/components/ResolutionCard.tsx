import type { Resolution } from "@/lib/mock-data";
import { Link } from "react-router-dom";

interface ResolutionCardProps {
  resolution: Resolution;
}

const typeLabel: Record<string, string> = {
  habit: "Habit bundle",
  outcome: "Measurable outcome",
  exploration: "Exploratory track",
};

const ResolutionCard = ({ resolution }: ResolutionCardProps) => {
  const isExited = resolution.status === "exited";

  return (
    <Link
      to={`/resolutions/${resolution.slug}`}
      className={`block border rounded-md p-4 transition-colors hover:bg-secondary/50 ${
        isExited ? "opacity-70" : ""
      }`}
    >
      <h3 className="text-base font-medium text-foreground">{resolution.name}</h3>
      <div className="mt-2 space-y-1">
        <p className="text-sm text-muted-foreground">• {typeLabel[resolution.type]}</p>
        {resolution.phase && (
          <p className="text-sm text-muted-foreground">• Phase: {resolution.phase}</p>
        )}
        {isExited && (
          <p className="text-sm text-muted-foreground">
            • Status: Exited <span className="text-xs">(reflection saved)</span>
          </p>
        )}
        {!isExited && (
          <p className="text-xs text-muted-foreground mt-2">
            Last activity: {resolution.lastActivity}
          </p>
        )}
      </div>
    </Link>
  );
};

export default ResolutionCard;
