// Mock data for Compass v0 — all data is local/static for now

export type ResolutionType = "habit" | "outcome" | "exploration";
export type ResolutionStatus = "active" | "paused" | "exited";

export interface Resolution {
  id: string;
  name: string;
  slug: string;
  type: ResolutionType;
  status: ResolutionStatus;
  phase?: string;
  purpose: string;
  constraints?: string[];
  lastActivity: string; // ISO date
  exitReason?: string;
}

export interface JournalEntry {
  id: string;
  date: string; // ISO date
  content: string;
  resolutionMentions?: string[]; // resolution ids
}

export interface Signal {
  id: string;
  resolutionId: string;
  resolutionName: string;
  text: string;
  detail?: string;
}

export interface WeeklyReflection {
  id: string;
  weekLabel: string;
  dateRange: string;
  content: string;
  resolutionSummaries: { name: string; rhythm: string; tone: string; entries: number }[];
  note?: string;
}

// Heatmap data: date string -> activity count
export type HeatmapData = Record<string, number>;

function generateHeatmap(): HeatmapData {
  const data: HeatmapData = {};
  const today = new Date();
  for (let i = 0; i < 120; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().split("T")[0];
    // Sparse, realistic pattern
    const rand = Math.random();
    if (rand > 0.4) {
      data[key] = rand > 0.85 ? 3 : rand > 0.65 ? 2 : 1;
    }
  }
  return data;
}

export const heatmapData = generateHeatmap();

export const resolutions: Resolution[] = [
  {
    id: "french-exam",
    name: "French exam preparation",
    slug: "french-exam",
    type: "outcome",
    status: "active",
    phase: "Intensive (Jan–Jun)",
    purpose: "Build durable reading and listening fluency for a high-stakes exam.",
    constraints: ["Limited evening energy", "Need variety to avoid burnout"],
    lastActivity: "2026-02-14",
  },
  {
    id: "morning-systems",
    name: "Morning systems",
    slug: "morning-systems",
    type: "habit",
    status: "active",
    phase: "Maintenance",
    purpose: "Anchor the day with a calm, intentional start.",
    constraints: ["Variable sleep quality"],
    lastActivity: "2026-02-15",
  },
  {
    id: "career-exploration",
    name: "Career exploration",
    slug: "career-exploration",
    type: "exploration",
    status: "exited",
    purpose: "Map interesting directions without forcing premature commitment.",
    exitReason: "Shifted focus to concrete skill-building after initial exploration phase felt complete.",
    lastActivity: "2026-01-20",
  },
  {
    id: "professional-visibility",
    name: "Professional visibility",
    slug: "professional-visibility",
    type: "exploration",
    status: "active",
    purpose: "Build presence without forcing artificial output.",
    constraints: ["Avoid performative content"],
    lastActivity: "2026-02-12",
  },
];

export const journalEntries: JournalEntry[] = [
  {
    id: "j1",
    date: "2026-02-15",
    content: "Spent the morning reviewing verb conjugations. Felt smoother than last week — the spaced repetition is working. Didn't push too hard in the evening, read a chapter of a novel in French instead.",
    resolutionMentions: ["french-exam"],
  },
  {
    id: "j2",
    date: "2026-02-14",
    content: "Woke up early, did the full morning routine. Journaled, stretched, made coffee slowly. The day felt different when it starts this way.",
    resolutionMentions: ["morning-systems"],
  },
  {
    id: "j3",
    date: "2026-02-13",
    content: "Wrote a short post about something I learned during the sabbatical. Wasn't sure if it was good enough but posted it anyway. That felt like progress.",
    resolutionMentions: ["professional-visibility"],
  },
  {
    id: "j4",
    date: "2026-02-11",
    content: "Low energy day. Did a single listening exercise and called it enough. Some days that's what showing up looks like.",
    resolutionMentions: ["french-exam"],
  },
  {
    id: "j5",
    date: "2026-02-09",
    content: "Tried a new study approach — watching French YouTube with active note-taking. More engaging than textbook drills. Not sure if it's efficient but it felt alive.",
    resolutionMentions: ["french-exam"],
  },
];

export const signals: Signal[] = [
  {
    id: "s1",
    resolutionId: "french-exam",
    resolutionName: "French exam",
    text: "Effort present, progress language absent",
    detail: "Recent entries describe showing up consistently but rarely mention improvement or advancement. This may reflect a plateau or simply a phase where growth is happening below the surface.",
  },
  {
    id: "s2",
    resolutionId: "morning-systems",
    resolutionName: "Morning systems",
    text: "Current expectations may exceed capacity",
    detail: "The full routine is attempted on days with poor sleep. Consider a minimal version for low-energy mornings.",
  },
];

export const weeklyReflections: WeeklyReflection[] = [
  {
    id: "w1",
    weekLabel: "This week",
    dateRange: "Feb 10–16",
    resolutionSummaries: [
      { name: "French exam", rhythm: "steady", tone: "effort-focused", entries: 4 },
      { name: "Morning systems", rhythm: "consistent", tone: "calm", entries: 3 },
      { name: "Professional visibility", rhythm: "light", tone: "tentative", entries: 1 },
    ],
    content: "This week reflected a steady rhythm across French study and morning routines. Professional visibility saw a single but meaningful action — publishing despite uncertainty. The overall tone suggests someone honoring their constraints rather than fighting them.",
    note: "Capacity limits shaped this week more than motivation.",
  },
  {
    id: "w2",
    weekLabel: "Last week",
    dateRange: "Feb 3–9",
    resolutionSummaries: [
      { name: "French exam", rhythm: "variable", tone: "experimental", entries: 3 },
      { name: "Morning systems", rhythm: "inconsistent", tone: "neutral", entries: 2 },
    ],
    content: "A week of experimentation. New study methods were tried for French, and morning routines were disrupted by schedule changes. Neither pattern suggests concern — variability is a feature of adjustment, not a sign of decline.",
    note: "Exploration of new methods is itself a form of engagement.",
  },
];
