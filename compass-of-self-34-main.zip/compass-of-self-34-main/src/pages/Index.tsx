import AppShell from "@/components/AppShell";
import ActivityHeatmap from "@/components/ActivityHeatmap";
import ReframeCallout from "@/components/ReframeCallout";
import { heatmapData, signals, resolutions, journalEntries } from "@/lib/mock-data";
import { Link } from "react-router-dom";
import { PenLine } from "lucide-react";

const Dashboard = () => {
  const activeResolutions = resolutions.filter((r) => r.status === "active");

  // This week's entries
  const today = new Date();
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);
  const recentEntries = journalEntries.filter(
    (e) => new Date(e.date) >= weekAgo
  );

  // Resolution activity summary for the week
  const resolutionActivity = activeResolutions.map((r) => {
    const entries = recentEntries.filter(
      (e) => e.resolutionMentions?.includes(r.id)
    );
    return { name: r.name, entries: entries.length };
  });

  return (
    <AppShell>
      <section className="space-y-8">
        <div>
          <h1 className="text-xl font-medium text-foreground">What has been happening</h1>
        </div>

        {/* Heatmap */}
        <div className="border rounded-md p-5 bg-card">
          <ActivityHeatmap data={heatmapData} weeks={16} />
        </div>

        {/* Journal CTA */}
        <Link
          to="/journal"
          className="flex items-center gap-3 border rounded-md p-4 bg-card hover:bg-secondary/50 transition-colors"
        >
          <PenLine className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
          <span className="text-sm text-muted-foreground">Write an entry</span>
        </Link>

        {/* Signals */}
        {signals.length > 0 && (
          <div className="space-y-3">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
              Strategic signals
            </h2>
            {signals.map((s) => (
              <ReframeCallout key={s.id} signal={s} />
            ))}
          </div>
        )}

        {/* This week summary */}
        <div className="space-y-3">
          <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            This week
          </h2>
          {resolutionActivity.map((ra) => (
            <div key={ra.name} className="text-sm">
              <span className="font-medium text-foreground">{ra.name}</span>
              <p className="text-muted-foreground mt-0.5">
                {ra.entries > 0
                  ? `• ${ra.entries} ${ra.entries === 1 ? "entry" : "entries"} this week`
                  : "• Quiet week (no entries)"}
              </p>
            </div>
          ))}
        </div>
      </section>
    </AppShell>
  );
};

export default Dashboard;
