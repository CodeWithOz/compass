import { useState } from "react";
import AppShell from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Check } from "lucide-react";

const Journal = () => {
  const [content, setContent] = useState("");
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (!content.trim()) return;
    setSaved(true);
    setTimeout(() => {
      setContent("");
      setSaved(false);
    }, 2000);
  };

  return (
    <AppShell>
      <section className="space-y-6">
        <h1 className="text-xl font-medium text-foreground">New journal entry</h1>

        {!saved ? (
          <>
            <div className="border rounded-md bg-card overflow-hidden">
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Just write. Messy is fine."
                className="min-h-[240px] border-0 bg-transparent resize-none text-sm leading-relaxed focus-visible:ring-0 p-5"
              />
            </div>

            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                Analysis will appear later.
              </p>
              <Button
                onClick={handleSave}
                disabled={!content.trim()}
                size="sm"
                className="px-6"
              >
                Add entry
              </Button>
            </div>
          </>
        ) : (
          <div className="border rounded-md p-5 bg-card flex items-center gap-3 animate-fade-in">
            <Check className="h-4 w-4 text-primary" strokeWidth={1.5} />
            <div>
              <p className="text-sm font-medium text-foreground">Entry saved</p>
              <p className="text-xs text-muted-foreground">Analysis pending…</p>
            </div>
          </div>
        )}
      </section>
    </AppShell>
  );
};

export default Journal;
