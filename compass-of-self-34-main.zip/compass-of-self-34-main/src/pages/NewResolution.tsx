import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

const NewResolution = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [purpose, setPurpose] = useState("");
  const [type, setType] = useState("outcome");
  const [constraints, setConstraints] = useState("");
  const [worthwhile, setWorthwhile] = useState("");

  const handleSubmit = () => {
    if (!name.trim()) return;
    // In v0, just navigate back — no persistence yet
    navigate("/resolutions");
  };

  return (
    <AppShell>
      <section className="max-w-xl mx-auto space-y-8">
        <div className="space-y-2">
          <h1 className="text-xl font-medium text-foreground">New Resolution</h1>
          <p className="text-sm text-muted-foreground">
            This is a direction you intend to take seriously — not a promise to perform.
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="name" className="text-sm text-muted-foreground">
            Working name
          </Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Professional visibility"
            className="bg-card"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="purpose" className="text-sm text-muted-foreground">
            Why this matters to you
          </Label>
          <Textarea
            id="purpose"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            placeholder="What makes this worth your attention right now?"
            className="min-h-[180px] bg-card resize-none text-sm leading-relaxed"
          />
        </div>

        <div className="space-y-3">
          <Label className="text-sm text-muted-foreground">
            What kind of resolution is this?
          </Label>
          <RadioGroup value={type} onValueChange={setType} className="flex flex-col sm:flex-row gap-3">
            {[
              { value: "outcome", label: "Outcome-oriented" },
              { value: "habit", label: "Habit-oriented" },
              { value: "exploration", label: "Exploratory" },
            ].map((option) => (
              <div key={option.value} className="flex items-center gap-2">
                <RadioGroupItem value={option.value} id={option.value} />
                <Label htmlFor={option.value} className="text-sm font-normal cursor-pointer">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>

        <div className="space-y-2">
          <Label htmlFor="constraints" className="text-sm text-muted-foreground">
            Constraints you're working within
          </Label>
          <Textarea
            id="constraints"
            value={constraints}
            onChange={(e) => setConstraints(e.target.value)}
            placeholder="Time limits, energy, competing priorities…"
            className="min-h-[100px] bg-card resize-none text-sm leading-relaxed"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="worthwhile" className="text-sm text-muted-foreground">
            What would make this feel worthwhile?
          </Label>
          <Textarea
            id="worthwhile"
            value={worthwhile}
            onChange={(e) => setWorthwhile(e.target.value)}
            placeholder="Not a metric — a feeling or outcome you'd recognize."
            className="min-h-[100px] bg-card resize-none text-sm leading-relaxed"
          />
        </div>

        <div className="flex flex-col-reverse sm:flex-row gap-3 sm:justify-end pt-2">
          <Button variant="ghost" onClick={() => navigate("/resolutions")}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!name.trim()}>
            Begin this resolution
          </Button>
        </div>
      </section>
    </AppShell>
  );
};

export default NewResolution;
