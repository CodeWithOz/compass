import AppShell from "@/components/AppShell";
import ReflectionCard from "@/components/ReflectionCard";
import { weeklyReflections } from "@/lib/mock-data";

const Reflections = () => {
  return (
    <AppShell>
      <section className="space-y-6">
        <h1 className="text-xl font-medium text-foreground">Reflections</h1>
        <p className="text-sm text-muted-foreground">
          Weekly observations. Not directives — just what the data seems to suggest.
        </p>

        <div className="space-y-4">
          {weeklyReflections.map((r) => (
            <ReflectionCard key={r.id} reflection={r} />
          ))}
        </div>
      </section>
    </AppShell>
  );
};

export default Reflections;
