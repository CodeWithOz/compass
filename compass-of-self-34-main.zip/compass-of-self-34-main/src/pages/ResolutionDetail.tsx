import { useParams, useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import ActivityHeatmap from "@/components/ActivityHeatmap";
import { resolutions, heatmapData, signals, journalEntries } from "@/lib/mock-data";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const ResolutionDetail = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const resolution = resolutions.find((r) => r.slug === slug);

  if (!resolution) {
    return (
      <AppShell>
        <p className="text-muted-foreground">Resolution not found.</p>
      </AppShell>
    );
  }

  const resolutionSignals = signals.filter((s) => s.resolutionId === resolution.id);
  const resolutionEntries = journalEntries
    .filter((e) => e.resolutionMentions?.includes(resolution.id))
    .slice(0, 5);

  return (
    <AppShell>
      <section className="space-y-6">
        <button
          onClick={() => navigate("/resolutions")}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" strokeWidth={1.5} />
          Back
        </button>

        <div>
          <h1 className="text-xl font-medium text-foreground">{resolution.name}</h1>
          {resolution.status === "exited" && (
            <span className="text-xs text-muted-foreground">Exited</span>
          )}
        </div>

        {/* Purpose */}
        <div className="space-y-2">
          <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Purpose</h2>
          <p className="text-sm text-foreground">{resolution.purpose}</p>
        </div>

        {/* Constraints */}
        {resolution.constraints && resolution.constraints.length > 0 && (
          <div className="space-y-2">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Constraints</h2>
            <ul className="space-y-1">
              {resolution.constraints.map((c) => (
                <li key={c} className="text-sm text-foreground">• {c}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Heatmap */}
        {resolution.status !== "exited" && (
          <div className="border rounded-md p-5 bg-card">
            <ActivityHeatmap data={heatmapData} weeks={12} />
          </div>
        )}

        {/* Signals */}
        {resolutionSignals.length > 0 && (
          <div className="space-y-3">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Signals</h2>
            {resolutionSignals.map((s) => (
              <div key={s.id} className="border border-signal-border bg-signal-bg rounded-md p-4">
                <p className="text-sm text-foreground">• {s.text}</p>
                {s.detail && (
                  <p className="text-xs text-muted-foreground mt-2 leading-relaxed italic">
                    {s.detail}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Recent entries */}
        {resolutionEntries.length > 0 && (
          <div className="space-y-3">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Recent entries</h2>
            {resolutionEntries.map((e) => (
              <div key={e.id} className="border rounded-md p-4 space-y-1">
                <p className="text-xs text-muted-foreground">{e.date}</p>
                <p className="text-sm text-foreground leading-relaxed">{e.content}</p>
              </div>
            ))}
          </div>
        )}

        {/* Exit reason */}
        {resolution.exitReason && (
          <div className="space-y-2">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Exit reflection</h2>
            <p className="prose-reflection text-sm text-foreground leading-relaxed">
              {resolution.exitReason}
            </p>
          </div>
        )}

        {/* Archive button for active resolutions */}
        {resolution.status === "active" && (
          <div className="border-t pt-6">
            <Button variant="outline" size="sm" className="text-muted-foreground">
              Archive / Exit
            </Button>
          </div>
        )}
      </section>
    </AppShell>
  );
};

export default ResolutionDetail;
