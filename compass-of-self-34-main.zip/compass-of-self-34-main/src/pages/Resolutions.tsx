import AppShell from "@/components/AppShell";
import ResolutionCard from "@/components/ResolutionCard";
import { resolutions } from "@/lib/mock-data";

const Resolutions = () => {
  const active = resolutions.filter((r) => r.status !== "exited");
  const exited = resolutions.filter((r) => r.status === "exited");

  return (
    <AppShell>
      <section className="space-y-6">
        <h1 className="text-xl font-medium text-foreground">Resolutions</h1>

        <div className="space-y-3">
          {active.map((r) => (
            <ResolutionCard key={r.id} resolution={r} />
          ))}
          {exited.map((r) => (
            <ResolutionCard key={r.id} resolution={r} />
          ))}
        </div>
      </section>
    </AppShell>
  );
};

export default Resolutions;
