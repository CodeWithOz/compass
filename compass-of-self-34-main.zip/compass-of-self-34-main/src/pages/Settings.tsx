import AppShell from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

const Settings = () => {
  return (
    <AppShell>
      <section className="space-y-8">
        <h1 className="text-xl font-medium text-foreground">Settings & Export</h1>

        {/* Data export */}
        <div className="space-y-3">
          <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            Data export
          </h2>
          <p className="text-sm text-muted-foreground">
            Download all your journal entries, resolutions, and reflections.
          </p>
          <div className="flex gap-3">
            <Button variant="outline" size="sm">
              <Download className="h-3.5 w-3.5 mr-2" strokeWidth={1.5} />
              Export JSON
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-3.5 w-3.5 mr-2" strokeWidth={1.5} />
              Export CSV
            </Button>
          </div>
        </div>

        {/* AI config */}
        <div className="space-y-3 border-t pt-6">
          <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            AI provider
          </h2>
          <p className="text-sm text-muted-foreground">
            Configure which AI model interprets your journal entries and generates reflections.
          </p>
          <div className="border rounded-md p-4 bg-card">
            <p className="text-sm text-muted-foreground italic">
              Not yet configured. AI features will be available once a provider is connected.
            </p>
          </div>
        </div>

        {/* System info */}
        <div className="space-y-3 border-t pt-6">
          <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            System
          </h2>
          <p className="text-xs text-muted-foreground">
            Compass v0 · All data stored locally · No external services
          </p>
        </div>
      </section>
    </AppShell>
  );
};

export default Settings;
